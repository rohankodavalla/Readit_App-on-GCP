using Google.Cloud.Functions.Framework;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.Threading.Tasks;
using Google.Cloud.Bigtable.V2;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using Google.Cloud.Bigtable.Common.V2;

namespace order_function;

public class Function : IHttpFunction
{

    // Set up some Cloud Bigtable metadata for convenience
        // Your Google Cloud Platform project ID
        private const string projectId = "PROJECT_ID";

        // You Google Cloud Bigtable instance ID
        private const string instanceId = "readit-bt";

        // The name of a table.
        private const string tableId = "orders";
        // The name of a column family.
        private const string columnFamily = "omd";

    /// <summary>
    /// Logic for your function goes here.
    /// </summary>
    /// <param name="context">The HTTP context, containing the request and the response.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    public async Task HandleAsync(HttpContext context)
    {
        // BigtableClient API lets us read and write to a table.
        BigtableClient bigtableClient = BigtableClient.Create();

        var tableName = new Google.Cloud.Bigtable.Common.V2.TableName(projectId, instanceId, tableId);        

        Console.WriteLine("Order function activated...");
        var body=new StreamReader(context.Request.Body).ReadToEndAsync().Result;
        Console.WriteLine($"Order received: {body}");

        Console.WriteLine("Parsing order JSON...");
        dynamic order=JObject.Parse(body);
        var orderId = order.orderId.ToString();
        var orderDate = order.orderDate.ToString();
        var orderTotal = order.total.ToString();
        var priority = order.priority.ToString();
        var items = order.items.ToString();
        Console.WriteLine($"Order parsed. ID: {orderId}, date: {orderDate}, total: {orderTotal}, priority: {priority}, items: {items}");

        Console.WriteLine("Writing order to BigTable...");

        var mutations = new List<Mutation>();
        mutations.Add(Mutations.SetCell("omd", new BigtableByteString("id"), new BigtableByteString(orderId)));
        mutations.Add(Mutations.SetCell("omd", new BigtableByteString("date"), new BigtableByteString(orderDate)));
        mutations.Add(Mutations.SetCell("omd", new BigtableByteString("total"), new BigtableByteString(orderTotal)));
        mutations.Add(Mutations.SetCell("omd", new BigtableByteString("priority"), new BigtableByteString(priority)));
        mutations.Add(Mutations.SetCell("oi", new BigtableByteString("items"), new BigtableByteString(items)));
        bigtableClient.MutateRow(tableName, "order#" + orderId, mutations);

        Console.WriteLine("Order written successfully");            
        
        await context.Response.WriteAsync("Order handled successfully.");
        Console.WriteLine($"Order function completed");
    }
}
